<?php

namespace SchoolSoft\Events;

abstract class Event
{

}
