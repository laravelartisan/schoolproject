@extends('admin2.layouts.dashboard')

@section('content')
    <div class="row">
        <div class="col-sm-12">

            <h1>
                Hello I m here
            </h1>

        </div>
    </div>
@endsection